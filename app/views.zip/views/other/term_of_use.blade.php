@extends('layout.frontend')

@section('isi')
    <div id="bordered">
          <h3>Syarat & Ketentuan</h3>
            <hr />
          <div class="col-sm-12">
                
            </div>
        </div>
@stop