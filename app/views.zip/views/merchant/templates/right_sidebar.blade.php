
      <!-- Control Sidebar -->
      <aside class="control-sidebar control-sidebar-dark">
        <!-- Tab panes -->
        <div class="tab-content">
          <!-- Home tab content -->
          <div class="tab-pane active" id="control-sidebar-home-tab">
            <h3 class="control-sidebar-heading">4 Notifikasi Baru</h3>
            <ul class="control-sidebar-menu">
              <li>
                <a href="javascript::;">
                  <i class="menu-icon fa fa-shopping-cart bg-blue"></i>
                  <div class="menu-info">
                    <h4 class="control-sidebar-subheading">6 order baru</h4>
                    <p>11 April 2016 15:13</p>
                  </div>
                </a>
              </li>
              <li>
                <a href="javascript::;">
                  <i class="menu-icon fa fa-exclamation bg-orange"></i>
                  <div class="menu-info">
                    <h4 class="control-sidebar-subheading">Produk #123 out of stock!</h4>
                    <p>11 April 2016 14:31</p>
                  </div>
                </a>
              </li>
              <li>
                <a href="javascript::;">
                  <i class="menu-icon fa fa-flag bg-red"></i>
                  <div class="menu-info">
                    <h4 class="control-sidebar-subheading">Produk #89 was reported!</h4>
                    <p>11 April 2016 13:58</p>
                  </div>
                </a>
              </li>
              <li>
                <a href="javascript::;">
                  <i class="menu-icon fa fa-exclamation bg-orange"></i>
                  <div class="menu-info">
                    <h4 class="control-sidebar-subheading">Produk #123 out of stock!</h4>
                    <p>10 April 2016 20:31</p>
                  </div>
                </a>
              </li>
            </ul><!-- /.control-sidebar-menu -->

          </div><!-- /.tab-pane -->
        </div>
      </aside><!-- /.control-sidebar -->
      <!-- Add the sidebar's background. This div must be placed
           immediately after the control sidebar -->
      <div class="control-sidebar-bg"></div>