<!-- Main Footer -->
<footer class="main-footer">
  <!-- Default to the left -->
  <strong>Copyright &copy; 2016 <a href="//bandungmall.co.id">BandungMall.co.id</a>.</strong> All rights reserved.
</footer>
