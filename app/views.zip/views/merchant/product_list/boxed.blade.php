<div class="row">
  <div class="col-sm-4">
    <div class="box box-widget">
      <div class='box-body'>
        <img class="img-responsive pad" src=" dist/img/photo2.png" alt="Photo">
        <h4 class="text-center">Meja Makan</h4>
        <p class="text-center">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
        <div class="col-sm-6">
          <strong>ID Produk</strong>: 123
        </div>
        <div class="col-sm-6">
          <strong>Harga</strong>: Rp 125.000
        </div>
        <div class="col-sm-6">
          <strong>Diskon</strong>: 25% (s.d. 20 April 2016)
        </div>
        <div class="col-sm-6">
          <strong>Qty</strong>: 8
        </div>
      </div><!-- /.box-body -->
      <div class="box-footer no-padding">
        <ul class="nav nav-stacked">
          <li><a href="#" class="text-center"><i class="fa fa-pencil-square-o"></i> Edit </a></li>
        </ul>
      </div><!-- /.box-footer -->
    </div><!-- /.box -->
  </div>
</div>
